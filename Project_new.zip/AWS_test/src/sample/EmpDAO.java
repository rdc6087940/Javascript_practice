package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmpDAO {

	// DB 연결 관련 변수 선언
	String url ="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
	String userName = "admin";
	String password = "rladlscjf0!";
	String dbName = "COMPANY";

	/*public EmpDAO() throws SQLException {
		Connection con = DriverManager.getConnection(url+dbName,userName,password);
	}*/
	
	private EmpDAO() throws Exception {
		// 1. 드라이버 로딩 코드
		Class.forName("com.mysql.jdbc.Driver");
	}
	
	static EmpDAO dao=null;
	public static EmpDAO getInstance() throws Exception {
		if(dao==null) dao=new EmpDAO();
		return dao;
	}
	
	
	// DB Connect 함수
	private Connection driveConnect() throws SQLException {
		String url ="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
		String userName = "admin";
		String password = "rladlscjf0!";
		String dbName = "COMPANY";
		
		Connection con = DriverManager.getConnection(url+dbName,userName,password);
		return con;
	}

	
	public ArrayList<EmpVO> selectEmp() throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		try {
		// 2. 연결 객체 얻어오기
		con = driveConnect();
		// 3. sql 문장 만들기
		String sql = "SELECT * FROM EMP";
		// 4. 전송객체 얻어오기
		ps = con.prepareStatement(sql);
		// 5. 전송
		ResultSet rs = ps.executeQuery();
		ArrayList<EmpVO> list = new ArrayList<EmpVO>();
		while(rs.next()) {
			EmpVO vo = new EmpVO();
			vo.setEmpno(rs.getInt("EMPNO"));
			vo.setEname(rs.getString("ENAME"));
			vo.setJob(rs.getString("JOB"));
			vo.setMgr(rs.getInt("MGR"));
			vo.setHiredate(rs.getString("HIREDATE"));
			vo.setSal(rs.getDouble("SAL"));
			vo.setComm(rs.getDouble("COMM"));
			vo.setDeptno(rs.getInt("DEPTNO"));
			list.add(vo);
		}
		return list;
		}finally {
		// 6. 닫기
		ps.close();
		con.close();
		}
		
	}

	public void insertEmp(EmpVO vo) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		
		try {
			// 2. 연결 객체 얻어오기
			con = driveConnect();
			// 3. sql 문장 만들기
			String sql = "INSERT INTO EMP(EMPNO, ENAME,JOB,DEPTNO) VALUES(?, ?, ?, ?)";
			// 4. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			ps.setInt(1, vo.getEmpno());
			ps.setString(2, vo.getEname());
			ps.setString(3, vo.getJob());
			ps.setInt(4, vo.getDeptno());
			
			int rs = ps.executeUpdate();
			
		}finally {
			ps.close();
			con.close();
		}
		
	}

	public EmpVO viewEmp(String empno) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		
		try {
			// 2. 연결 객체 얻어오기
			con = driveConnect();
			// 3. sql 문장 만들기
			String sql = "SELECT * FROM EMP WHERE EMPNO=?";
			// 4. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, Integer.parseInt(empno));
			// 5. 전송
			ResultSet rs = ps.executeQuery();
			EmpVO vo = new EmpVO();
			while(rs.next()) {
				vo.setEmpno(rs.getInt("EMPNO"));
				vo.setEname(rs.getString("ENAME"));
				vo.setJob(rs.getString("JOB"));
				vo.setMgr(rs.getInt("MGR"));
				vo.setHiredate(rs.getString("HIREDATE"));
				vo.setSal(rs.getDouble("SAL"));
				vo.setComm(rs.getDouble("COMM"));
				vo.setDeptno(rs.getInt("DEPTNO"));
			}
			return vo;
			}finally {
			// 6. 닫기
			ps.close();
			con.close();
			}
	}
	
	public void deleteEmp(String empno) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		
		try {
			con = driveConnect();
			String sql = "DELETE FROM EMP WHERE EMPNO=?";

			ps = con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(empno));
			
			int rs = ps.executeUpdate();
		}finally {
			// 6. 닫기
			ps.close();
			con.close();
			}
	}
	
	public void modifyEmp(EmpVO vo) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		
		try {
			con = driveConnect();
			String sql = "UPDATE EMP SET EMPNO=?, ENAME=?, JOB=?, MGR=?, HIREDATE=?, SAL=?, COMM=?, DEPTNO=? WHERE EMPNO=?";
			
			
			ps = con.prepareStatement(sql);
			ps.setInt(1, vo.getEmpno());
			ps.setString(2, vo.getEname());
			ps.setString(3, vo.getJob());
			ps.setInt(4, vo.getMgr());
			ps.setString(5, vo.getHiredate());
			ps.setDouble(6, vo.getSal());
			ps.setDouble(7, vo.getComm());
			ps.setInt(8, vo.getDeptno());
			ps.setInt(9, vo.getEmpno());
			
			int rs = ps.executeUpdate();
		}finally {
			// 6. 닫기
			ps.close();
			con.close();
			}
	}
	
}

