package test;

public class PracticeVO {

	private int test_no;
	private String test_text;
	
	
	public int getTest_no() {
		return test_no;
	}
	public void setTest_no(int test_no) {
		this.test_no = test_no;
	}
	public String getTest_text() {
		return test_text;
	}
	public void setTest_text(String test_text) {
		this.test_text = test_text;
	}
	
}
