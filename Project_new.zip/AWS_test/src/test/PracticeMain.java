package test;

public class PracticeMain {

	public static void main(String[] args) throws Exception {
		PracticeDAO dao = new PracticeDAO();
		PracticeVO vo = new PracticeVO();
		
		vo.setTest_no(2);
		vo.setTest_text("Hello World");

		dao.addText(vo);
	}

}

