// 진짜 중요한 코드

package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class PracticeDAO {

	String url ="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
	String userName = "admin";
	String password = "rladlscjf0!";
	String dbName = "KOSMO";

	public PracticeDAO() throws SQLException {
		Connection con = DriverManager.getConnection(url+dbName,userName,password);
	}
	

	
	public void addText(PracticeVO vo) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DriverManager.getConnection(url+dbName,userName,password);
			String sql = "INSERT INTO KOSMOS VALUES(?,?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, vo.getTest_no());
			ps.setString(2, vo.getTest_text());
			
			ps.executeUpdate();
		}finally {
			ps.close();
			con.close();
		}	
	}
}
