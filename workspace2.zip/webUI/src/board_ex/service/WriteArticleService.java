package board_ex.service;

import java.text.DecimalFormat;

import board_ex.model.*;

public class WriteArticleService {
	
	private static WriteArticleService instance;
	public static WriteArticleService getInstance()  throws BoardException{
		if( instance == null )
		{
			instance = new WriteArticleService();
		}
		return instance;
	}
	
	public BoardVO write( BoardVO rec ) throws Exception{
		
		BoardDao dao = BoardDao.getInstance();
		dao.insert(rec);

		return rec;
		
	}
}
