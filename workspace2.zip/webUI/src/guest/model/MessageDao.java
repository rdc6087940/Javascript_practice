package guest.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import member.beans.MemberDao;

public class MessageDao {

	// DB 연결시  관한 변수 

	String url="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
	String userName = "admin";
	String password = "rladlscjf0!";
	String dbName = "PRAC03";


	// 데이터베이스 할당 싱글톤 패턴 ----------------------------------------------
	private MessageDao() throws Exception {
		// 1. 드라이버 로딩 코드
		Class.forName("com.mysql.jdbc.Driver");
	}
	static MessageDao dao=null;
	public static MessageDao getInstance() throws Exception {
		if(dao==null) dao=new MessageDao();
		return dao;
	}
	//---------------------------------------------------------------------

	// DB Connect 함수	---------------------------------------------------
	private Connection driveConnect() throws SQLException {
		String url ="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
		String userName = "admin";
		String password = "rladlscjf0!";
		String dbName = "PRAC03";

		Connection con = DriverManager.getConnection(url+dbName,userName,password);
		return con;
	}


	/*
	 * 메세지를 입력하는 함수
	 */
	public void insert(Message rec) throws MessageException, SQLException
	{
		Connection con = null;
		PreparedStatement ps = null;
		int rs;
		try{
			// 1. 연결객체(Connection) 얻어오기
			con= driveConnect();

			// 2. sql 문장 만들기
			String sql="INSERT INTO GuestTB(GUEST_NAME,PASSWORD,MESSAGE) VALUES(? ,?, ?)";

			// 3. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			ps.setString(1, rec.getGuest_name());
			ps.setString(2, rec.getPassword());
			ps.setString(3, rec.getMessage());;
			rs = ps.executeUpdate();



		}catch( Exception ex ){
			throw new MessageException("방명록 ) DB에 입력시 오류  : " + ex.toString() );	
		} finally{
			if( ps   != null ) { try{ ps.close();  } catch(SQLException ex){} }
			if( con  != null ) { try{ con.close(); } catch(SQLException ex){} }
		}

	}

	/*
	 * 메세지 목록 전체를 얻어올 때
	 */
	public List<Message> selectList() throws MessageException
	{
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Message> mList = new ArrayList<Message>();
		boolean isEmpty = true;

		try{
			con= driveConnect();
		// 2. sql 문장 만들기
		String sql="SELECT * FROM GuestTB";
		// 3. 전송객체 얻어오기
		ps = con.prepareStatement(sql);
		rs = ps.executeQuery();
		while(rs.next()) {
			isEmpty = false;
			Message msg = new Message();
			msg.setMessage_id(rs.getInt(1));
			msg.setGuest_name(rs.getString(2));
			msg.setPassword(rs.getString(3));
			msg.setMessage(rs.getString(4));
			mList.add(msg);
		}



		if( isEmpty ) return Collections.emptyList();

		return mList;
		}catch( Exception ex ){
			throw new MessageException("방명록 ) DB에 목록 검색시 오류  : " + ex.toString() );	
		} finally{
			if( rs   != null ) { try{ rs.close();  } catch(SQLException ex){} }
			if( ps   != null ) { try{ ps.close();  } catch(SQLException ex){} }
			if( con  != null ) { try{ con.close(); } catch(SQLException ex){} }
		}		
	}


	/* -------------------------------------------------------
	 * 현재 페이지에 보여울 메세지 목록  얻어올 때
	 */
	public List<Message> selectList(int firstRow, int endRow) throws MessageException
	{
		Connection	 		con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Message> mList = new ArrayList<Message>();
		boolean isEmpty = true;

		try{
			con= driveConnect();
			// 2. sql 문장 만들기
			String sql="select * from (select @rownum := @rownum + 1 as rn, GUEST_NAME, PASSWORD, MESSAGE from GuestTB, (select @rownum := 0)  as rowcolumn order by MESSAGE_ID ASC) as rownum_table where rn >= ? and rn <=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, firstRow);
			ps.setInt(2, endRow);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				isEmpty = false;
				Message msg = new Message();
				msg.setMessage_id(rs.getInt(1));
				msg.setGuest_name(rs.getString(2));
				msg.setPassword(rs.getString(3));
				msg.setMessage(rs.getString(4));
				mList.add(msg);
			}

			if( isEmpty ) return Collections.emptyList();

			return mList;
		}catch( Exception ex ){
			throw new MessageException("방명록 ) DB에 목록 검색시 오류  : " + ex.toString() );	
		} finally{
			if( rs   != null ) { try{ rs.close();  } catch(SQLException ex){} }
			if( ps   != null ) { try{ ps.close();  } catch(SQLException ex){} }
			if( con  != null ) { try{ con.close(); } catch(SQLException ex){} }
		}		
	}



	/* -------------------------------------------------------
	 * 메세지 전체 레코드 수를 검색
	 */

	public int getTotalCount() throws MessageException{
		Connection	 		con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;

		try{
			con= driveConnect();
			String sql="SELECT * FROM GuestTB";
			// 3. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				count++;
			}
			

			return  count;

		}catch( Exception ex ){
			throw new MessageException("방명록 ) DB에 목록 검색시 오류  : " + ex.toString() );	
		} finally{
			if( rs   != null ) { try{ rs.close();  } catch(SQLException ex){} }
			if( ps   != null ) { try{ ps.close();  } catch(SQLException ex){} }
			if( con  != null ) { try{ con.close(); } catch(SQLException ex){} }
		}			
	}

	/*
	 * 메세지 번호와 비밀번호에 의해 메세지 삭제
	 */
	public int delete( int messageId, String password ) throws MessageException
	{
		int result = 0;
		Connection con = null;
		PreparedStatement ps = null;
		int rs;
		System.out.println("데이터베이스 검사 id : "  +messageId);
		System.out.println("데이터베이스 검사 password : "  +password);
		
		try{	
			con= driveConnect();

			// 2. sql 문장 만들기
			String sql="DELETE FROM GuestTB WHERE MESSAGE_ID=? AND PASSWORD=?";
			
			// 3. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			ps.setInt(1, messageId);
			ps.setString(2, password);
			rs = ps.executeUpdate();
			
			sql = "ALTER TABLE GuestTB AUTO_INCREMENT=1";
			Statement stmt = con.createStatement();
			stmt.execute(sql);
			System.out.println("alter1번 완료");
			
			sql = "SET @COUNT = 0";
			stmt = con.createStatement();
			stmt.execute(sql);
			System.out.println("alter2번 완료");
			
			sql = "UPDATE GuestTB SET MESSAGE_ID = @COUNT:=@COUNT+1";
			stmt = con.createStatement();
			stmt.execute(sql);
			System.out.println("alter3번 완료");
			
			stmt.close();

			return 1;
		}catch( Exception ex ){
			throw new MessageException("방명록 ) DB에 삭제시 오류  : " + ex.toString() );	
		} finally{
			if( ps   != null ) { try{ ps.close();  } catch(SQLException ex){} }
			if( con  != null ) { try{ con.close(); } catch(SQLException ex){}
			}
		}		
	}
}
