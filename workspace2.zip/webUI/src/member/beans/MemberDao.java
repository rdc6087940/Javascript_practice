package member.beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberDao {

	
	// DB 연결시  관한 변수 

	String url="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
	String userName = "admin";
	String password = "rladlscjf0!";
	String dbName = "PRAC02";


	// 데이터베이스 할당 싱글톤 패턴 ----------------------------------------------
	private MemberDao() throws Exception {
		// 1. 드라이버 로딩 코드
		Class.forName("com.mysql.jdbc.Driver");
	}
	static MemberDao dao=null;
	public static MemberDao getInstance() throws Exception {
		if(dao==null) dao=new MemberDao();
		return dao;
	}
	//---------------------------------------------------------------------

	// DB Connect 함수	---------------------------------------------------
	private Connection driveConnect() throws SQLException {
		String url ="jdbc:mysql://kic.cj7mov3fe2u4.ap-northeast-2.rds.amazonaws.com/";
		String userName = "admin";
		String password = "rladlscjf0!";
		String dbName = "PRAC02";

		Connection con = DriverManager.getConnection(url+dbName,userName,password);
		return con;
	}
	
	/*******************************************
	 * * 회원관리테이블 MEMBERTEST 에  회원정보를 입력하는 함수
	 * @param rec
	 * @throws MemberException
	 * @throws SQLException 
	 */
	public int insertMember( Member rec ) throws MemberException, SQLException
	{
		Connection con = null;
		PreparedStatement ps = null;
		if(rec.getId() ==null) {
			return -2;	// 아이디 null
		}
		else if(rec.getPassword()==null) {
			return -3; // 패스워드 null
		}
		else if(rec.getName() == null) {
			return -4; // 이름 null
		}
		
		try {
			con = driveConnect();
			String sql = "INSERT INTO memberTest VALUES(?, ?, ?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, rec.getId());
			ps.setString(2, rec.getPassword());
			ps.setString(3, rec.getName());
			ps.setString(4, rec.getTel());
			ps.setString(5, rec.getAddr());
			
			int rs = ps.executeUpdate();
			return 1;
		}catch(Exception e){
			System.out.println("");
		}finally {
			con.close();
			ps.close();
		}		
		return -1;
	}
	
	/**********************************************************
	 * * 회원관리테이블 MEMBERTEST에서 기존의 id값과 중복되는지 확인하는 함수
	 * @throws SQLException 
	 */
	public boolean isDuplicatedId( String id ) throws MemberException, SQLException
	{
		boolean flag = false;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			con = driveConnect();
			String sql = "SELECT id FROM memberTest WHERE id=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(id) || id==null || id.equals("")) {
					return true;	// 중복있음
				}
			}
			return false;	// 중복없음
			
		}catch( Exception ex ){
			throw new MemberException("중복아이디 검사시 오류  : " + ex.toString() );			
		}finally {
			
			con.close();
			ps.close();
			rs.close();
			
		}
			
	}
}
