$(function(){
	$('.accordion').accordion({
		active:1,
		heightStyle:'content'
	});
	
})